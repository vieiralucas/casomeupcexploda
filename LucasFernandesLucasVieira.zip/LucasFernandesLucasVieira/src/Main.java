import gui.Frame;

/**
 * Created by lucas on 10/29/16.
 */
public class Main {
    private Frame frame;

    public Main() {
        frame = new Frame();

        frame.setVisible(true);
    }

    public static void main(String args[]) {
        new Main();
    }
}
